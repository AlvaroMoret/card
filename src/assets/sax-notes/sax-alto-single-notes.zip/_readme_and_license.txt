Sound pack downloaded from Freesound
----------------------------------------

"Sax Alto single notes"

This pack of sounds contains sounds by the following user:
 - MTG ( https://freesound.org/people/MTG/ )

You can find this pack online at: https://freesound.org/people/MTG/packs/20239/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 3.0: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 358442__mtg__sax-alto-a5.wav
    * url: https://freesound.org/s/358442/
    * license: Attribution 3.0
  * 358441__mtg__sax-alto-g-5.wav
    * url: https://freesound.org/s/358441/
    * license: Attribution 3.0
  * 358440__mtg__sax-alto-g5.wav
    * url: https://freesound.org/s/358440/
    * license: Attribution 3.0
  * 358439__mtg__sax-alto-f-5.wav
    * url: https://freesound.org/s/358439/
    * license: Attribution 3.0
  * 358438__mtg__sax-alto-f5.wav
    * url: https://freesound.org/s/358438/
    * license: Attribution 3.0
  * 358437__mtg__sax-alto-e5.wav
    * url: https://freesound.org/s/358437/
    * license: Attribution 3.0
  * 358436__mtg__sax-alto-d-5.wav
    * url: https://freesound.org/s/358436/
    * license: Attribution 3.0
  * 358435__mtg__sax-alto-d5.wav
    * url: https://freesound.org/s/358435/
    * license: Attribution 3.0
  * 358434__mtg__sax-alto-c-5.wav
    * url: https://freesound.org/s/358434/
    * license: Attribution 3.0
  * 358433__mtg__sax-alto-c5.wav
    * url: https://freesound.org/s/358433/
    * license: Attribution 3.0
  * 358432__mtg__sax-alto-b4.wav
    * url: https://freesound.org/s/358432/
    * license: Attribution 3.0
  * 358431__mtg__sax-alto-a-4.wav
    * url: https://freesound.org/s/358431/
    * license: Attribution 3.0
  * 358430__mtg__sax-alto-a4.wav
    * url: https://freesound.org/s/358430/
    * license: Attribution 3.0
  * 358429__mtg__sax-alto-g-4.wav
    * url: https://freesound.org/s/358429/
    * license: Attribution 3.0
  * 358428__mtg__sax-alto-g4.wav
    * url: https://freesound.org/s/358428/
    * license: Attribution 3.0
  * 358427__mtg__sax-alto-f-4.wav
    * url: https://freesound.org/s/358427/
    * license: Attribution 3.0
  * 358426__mtg__sax-alto-f4.wav
    * url: https://freesound.org/s/358426/
    * license: Attribution 3.0
  * 358425__mtg__sax-alto-e4.wav
    * url: https://freesound.org/s/358425/
    * license: Attribution 3.0
  * 358424__mtg__sax-alto-d-4.wav
    * url: https://freesound.org/s/358424/
    * license: Attribution 3.0
  * 358423__mtg__sax-alto-d4.wav
    * url: https://freesound.org/s/358423/
    * license: Attribution 3.0
  * 358422__mtg__sax-alto-c-4.wav
    * url: https://freesound.org/s/358422/
    * license: Attribution 3.0
  * 358421__mtg__sax-alto-c4.wav
    * url: https://freesound.org/s/358421/
    * license: Attribution 3.0
  * 358420__mtg__sax-alto-b3.wav
    * url: https://freesound.org/s/358420/
    * license: Attribution 3.0
  * 358419__mtg__sax-alto-a-3.wav
    * url: https://freesound.org/s/358419/
    * license: Attribution 3.0
  * 358418__mtg__sax-alto-a3.wav
    * url: https://freesound.org/s/358418/
    * license: Attribution 3.0
  * 358417__mtg__sax-alto-g-3.wav
    * url: https://freesound.org/s/358417/
    * license: Attribution 3.0
  * 358416__mtg__sax-alto-g3.wav
    * url: https://freesound.org/s/358416/
    * license: Attribution 3.0
  * 358415__mtg__sax-alto-f-3.wav
    * url: https://freesound.org/s/358415/
    * license: Attribution 3.0
  * 358414__mtg__sax-alto-f3.wav
    * url: https://freesound.org/s/358414/
    * license: Attribution 3.0
  * 358413__mtg__sax-alto-e3.wav
    * url: https://freesound.org/s/358413/
    * license: Attribution 3.0
  * 358412__mtg__sax-alto-d-3.wav
    * url: https://freesound.org/s/358412/
    * license: Attribution 3.0
  * 358411__mtg__sax-alto-d3.wav
    * url: https://freesound.org/s/358411/
    * license: Attribution 3.0
  * 358410__mtg__sax-alto-c-3.wav
    * url: https://freesound.org/s/358410/
    * license: Attribution 3.0
  * 358409__mtg__sax-alto-a5.wav
    * url: https://freesound.org/s/358409/
    * license: Attribution 3.0
  * 358408__mtg__sax-alto-g-5.wav
    * url: https://freesound.org/s/358408/
    * license: Attribution 3.0
  * 358407__mtg__sax-alto-g5.wav
    * url: https://freesound.org/s/358407/
    * license: Attribution 3.0
  * 358406__mtg__sax-alto-f-5.wav
    * url: https://freesound.org/s/358406/
    * license: Attribution 3.0
  * 358405__mtg__sax-alto-f5.wav
    * url: https://freesound.org/s/358405/
    * license: Attribution 3.0
  * 358404__mtg__sax-alto-e5.wav
    * url: https://freesound.org/s/358404/
    * license: Attribution 3.0
  * 358403__mtg__sax-alto-d-5.wav
    * url: https://freesound.org/s/358403/
    * license: Attribution 3.0
  * 358402__mtg__sax-alto-d5.wav
    * url: https://freesound.org/s/358402/
    * license: Attribution 3.0
  * 358401__mtg__sax-alto-c-5.wav
    * url: https://freesound.org/s/358401/
    * license: Attribution 3.0
  * 358400__mtg__sax-alto-c5.wav
    * url: https://freesound.org/s/358400/
    * license: Attribution 3.0
  * 358399__mtg__sax-alto-b4.wav
    * url: https://freesound.org/s/358399/
    * license: Attribution 3.0
  * 358398__mtg__sax-alto-a-4.wav
    * url: https://freesound.org/s/358398/
    * license: Attribution 3.0
  * 358397__mtg__sax-alto-a4.wav
    * url: https://freesound.org/s/358397/
    * license: Attribution 3.0
  * 358396__mtg__sax-alto-g-4.wav
    * url: https://freesound.org/s/358396/
    * license: Attribution 3.0
  * 358395__mtg__sax-alto-g4.wav
    * url: https://freesound.org/s/358395/
    * license: Attribution 3.0
  * 358394__mtg__sax-alto-f-4.wav
    * url: https://freesound.org/s/358394/
    * license: Attribution 3.0
  * 358393__mtg__sax-alto-f4.wav
    * url: https://freesound.org/s/358393/
    * license: Attribution 3.0
  * 358392__mtg__sax-alto-e4.wav
    * url: https://freesound.org/s/358392/
    * license: Attribution 3.0
  * 358391__mtg__sax-alto-d-4.wav
    * url: https://freesound.org/s/358391/
    * license: Attribution 3.0
  * 358390__mtg__sax-alto-d4.wav
    * url: https://freesound.org/s/358390/
    * license: Attribution 3.0
  * 358389__mtg__sax-alto-c-4.wav
    * url: https://freesound.org/s/358389/
    * license: Attribution 3.0
  * 358388__mtg__sax-alto-c4.wav
    * url: https://freesound.org/s/358388/
    * license: Attribution 3.0
  * 358387__mtg__sax-alto-b3.wav
    * url: https://freesound.org/s/358387/
    * license: Attribution 3.0
  * 358386__mtg__sax-alto-a-3.wav
    * url: https://freesound.org/s/358386/
    * license: Attribution 3.0
  * 358385__mtg__sax-alto-a3.wav
    * url: https://freesound.org/s/358385/
    * license: Attribution 3.0
  * 358384__mtg__sax-alto-g-3.wav
    * url: https://freesound.org/s/358384/
    * license: Attribution 3.0
  * 358383__mtg__sax-alto-g3.wav
    * url: https://freesound.org/s/358383/
    * license: Attribution 3.0
  * 358382__mtg__sax-alto-f-3.wav
    * url: https://freesound.org/s/358382/
    * license: Attribution 3.0
  * 358381__mtg__sax-alto-f3.wav
    * url: https://freesound.org/s/358381/
    * license: Attribution 3.0
  * 358380__mtg__sax-alto-e3.wav
    * url: https://freesound.org/s/358380/
    * license: Attribution 3.0
  * 358379__mtg__sax-alto-d-3.wav
    * url: https://freesound.org/s/358379/
    * license: Attribution 3.0
  * 358378__mtg__sax-alto-d3.wav
    * url: https://freesound.org/s/358378/
    * license: Attribution 3.0
  * 358377__mtg__sax-alto-c-3.wav
    * url: https://freesound.org/s/358377/
    * license: Attribution 3.0


